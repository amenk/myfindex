self soft MyFiles
-----------------

Die aktuelle Version von self soft MyFiles gibt es stets
auf http://www.self-soft.de


Bei Fragen zur Benutzung lies bitte zuerst die Datei
FAQ.htm. Bei weiteren Fragen benutze das Forum auf
www.self-soft.de oder wende dich per eMail an mich.

Alexander Menk
www.self-soft.de
self@self-soft.de




Hinweis: 
Diese Software enth�lt Code von Andrey V. Sorokin 
Copyright (c) 1999-2001 by Andrey V. Sorokin <anso@mail.ru> 
(Regul�re Ausdr�cke)
